﻿using System;
using System.Xml.Schema;

namespace Hweek3
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            string make;
            string model;
            int speed1;
            int speed2;
            int speed3;
            int demerit;
            


            Console.WriteLine("Enter the speed limit :");
            int speedL = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("Speed Limit is: " + speedL + "mph");

            Console.WriteLine("Please enter the information of 3 cars : ");

            Car c = new Car();
            Car c2 = new Car();
            Car c3 = new Car();

            Console.WriteLine("Enter the Make of the car :");
            make = Console.ReadLine();
            c.make = make;

            Console.WriteLine("Enter the Model of the car :");
            model = Console.ReadLine();
            c.model = model;

            Console.WriteLine("Enter the speed limit of the car :");
            speed1 = Convert.ToInt32(Console.ReadLine());
            c.mph = speed1;
               

            //

            Console.WriteLine("Enter the Make of the car :");
            make = Console.ReadLine();
            c2.make = make;

            Console.WriteLine("Enter the Model of the car :");
            model = Console.ReadLine();
            c2.model = model;

            Console.WriteLine("Enter the speed limit of the car :");
            speed2 = Convert.ToInt32(Console.ReadLine());
            c2.mph = speed2;
           
            //
            Console.WriteLine("Enter the Make of the car :");
            make = Console.ReadLine();
            c3.make = make;

            Console.WriteLine("Enter the Model of the car :");
            model = Console.ReadLine();
            c3.model = model;

            Console.WriteLine("Enter the speed limit of the car :");
            speed3 = Convert.ToInt32(Console.ReadLine());
            c3.mph = speed3;


            Console.WriteLine("Speed Limit is: " + speedL + "mph");

            if (speed1 <= speedL)
            {
                Console.WriteLine(c.make + " " + c.model + " " + c.mph + "mph: " + " OK ");
            }
            else
            {
                if (speed1 > speedL)
                {
                    demerit = (speed1 - speedL) / 5;
                    if (demerit > 10)
                    {
                        Console.WriteLine(c.make + " " + c.model + " " + c.mph + "mph: " + demerit + " demerits <LICENSE SUSPENDED>");
                    }
                    else
                    {
                        Console.WriteLine(c.make + " " + c.model + " " + c.mph + "mph: " + demerit + " demerits");
                    }

                }



            }

            if (speed2 <= speedL)
            {
                Console.WriteLine(c2.make + " " + c2.model + " " + c2.mph + "mph: " + " OK ");
            }
            else
            {
                if (speed2 > speedL)
                {
                    demerit = (speed2 - speedL) / 5;
                    if (demerit > 10)
                    {
                        Console.WriteLine(c2.make + " " + c2.model + " " + c2.mph + "mph: " + demerit + " demerits <LICENSE SUSPENDED>");
                    }
                    else
                    {
                        Console.WriteLine(c2.make + " " + c2.model + " " + c2.mph + "mph: " + demerit + " demerits");
                    }

                }



            }

            if (speed3 <= speedL)
            {
                Console.WriteLine(c3.make + " " + c3.model + " " + c3.mph + "mph: " + " OK ");
            }
            else
            {
                if (speed3 > speedL)
                {
                    demerit = (speed3 - speedL) / 5;
                    if (demerit > 10)
                    {
                        Console.WriteLine(c3.make + " " + c3.model + " " + c3.mph + "mph: " + demerit + " demerits <LICENSE SUSPENDED>");
                    }
                    else
                    {
                        Console.WriteLine(c3.make + " " + c3.model + " " + c3.mph + "mph: " + demerit + " demerits");
                    }

                }



            }








        }


    }
    // i was trying so hard to condence everything but im still learning 
    public class Car
    {
        public string make;
        public string model;
        public int mph;

    }
}